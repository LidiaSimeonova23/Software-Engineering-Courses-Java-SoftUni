package lecture13DefiningClasses.p02Constructors;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int carsNumber = Integer.parseInt(scanner.nextLine());    //от първия ред на конзолата четем брой обекти (коли) в класа

        for (int car = 1; car <= carsNumber; car++) {
            String[] carPartsArray = scanner.nextLine().split(" ");     //на всяка итерация четем данни (от конзолата) за текущия обект (текущата кола)

            Car currentCar = new Car();

            if (carPartsArray.length == 3) {
                currentCar = new Car(
                        carPartsArray[0], carPartsArray[1], Integer.parseInt(carPartsArray[2]));
            } else {
                currentCar = new Car(carPartsArray[0]);
            }

            System.out.println(currentCar.toString());
            //или просто    System.out.println(currentCar);
        }

    }
}
